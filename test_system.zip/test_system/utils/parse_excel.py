import pandas as pd

def parse_excel_file(filepath):
    """
    Parses the uploaded Excel file and converts each row into a question dictionary
    suitable for MongoDB insertion.

    Expected Excel columns:
    - Q. No
    - Type (e.g., SCQ for single choice question)
    - question
    - option_a
    - option_b
    - option_c
    - option_d
    - correct_asnwer (e.g., a, b, c, d)
    """

    df = pd.read_excel(filepath)

    questions = []

    for index, row in df.iterrows():
        try:
            # Normalize question type
            type_str = str(row["Type"]).strip().upper()
            question_type = "single" if type_str == "SCQ" else "multi"

            # Collect and strip options
            options = [
                str(row["option_a"]).strip(),
                str(row["option_b"]).strip(),
                str(row["option_c"]).strip(),
                str(row["option_d"]).strip()
            ]

            # Correct answer is a letter (a, b, c, d)
            letter = str(row["correct_asnwer"]).strip().lower()
            option_map = {"a": 0, "b": 1, "c": 2, "d": 3}

            if letter not in option_map:
                print(f"⚠️ Skipping row {index+1}: Invalid correct_asnwer = {letter}")
                continue

            correct = options[option_map[letter]]

            question = {
                "question": str(row["question"]).strip(),
                "options": options,
                "type": question_type,
                "correct_answer": correct
            }

            questions.append(question)

        except Exception as e:
            print(f"❌ Error parsing row {index+1}: {e}")

    return questions
